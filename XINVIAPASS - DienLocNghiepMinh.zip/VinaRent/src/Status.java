
public enum Status {
	READY,
	HELD,
	RESERVED,
	RETURNED,
	SERVICE_NEEDED,
	REMOVED
}
