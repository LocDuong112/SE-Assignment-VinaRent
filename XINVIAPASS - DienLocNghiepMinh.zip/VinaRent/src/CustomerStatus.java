
public enum CustomerStatus {
	NORMAL,
	BLACKLISTED,
	DISCOUNT
}
