
public enum Group {
	A,B,C,D,E
}
