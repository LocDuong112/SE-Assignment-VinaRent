
public enum Transmission {
	automatic,
	manual
}
