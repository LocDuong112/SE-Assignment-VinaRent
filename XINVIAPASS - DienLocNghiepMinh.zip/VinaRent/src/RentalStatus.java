
public enum RentalStatus {
	NOT_RETURNED,
	RETURNED,
	EXCEPTIONAL
}
